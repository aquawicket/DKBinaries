var working = true;

//////////////////////////////
function DKBuildConsole_Init()
{
	DKDEBUGFUNC();
	DKCreate("DKBuild/DKBuild.js", function(){
		DKBuild_ValidateCmake();
		//DKBuild_ValidateVC2015();
		DKBuild_ValidateVC2019();
		DKBuild_ValidateGcc();
		DKBuild_ValidateXcode();
	
		while(working){
			DKBuildConsole_Process();
		}
	});
}

/////////////////////////////
function DKBuildConsole_End()
{
	DKDEBUGFUNC();
	DKClose("DKBuild/DKBuild.js");
}

//////////////////////////////////////
function DKBuildConsole_ChooseUpdate()
{
	DKDEBUGFUNC();
	console.log("\n");
	console.log("**** Update DigitalKnob ??? ****");
	console.log("Y. Update");
	console.log("C. Commit");
	console.log("R. Reset Apps and Plugins");
	console.log("X. Reset Everything");
	console.log("any other key to Skip");
	console.log("ESC. exit");
	console.log("\n");
	
	var key = 10;
	while(key == 10){ //unix fix
		key = DK_GetKey();
	}
	
	//console.log("Key pressed: "+String(key)+"");
	
	if(key == 27){ //Esc key
		DK_Exit();
	}
	if(key == 121){ //y key
		DKCreate("DKGit/DKGit.js", function(){
			DKGit_GitUpdate();
		});
	}
	if(key == 99){ //c key
		DKCreate("DKGit/DKGit.js", function(){
			DKGit_GitCommit();
		});
	}
	if(key == 114){ //r key
		DKBuild_ResetAppsPlugins();
		DKGit_GitUpdate();
	}
	if(key == 120){ //x key
		DKBuild_Reset3rdParty();
		DKBuild_ResetAppsPlugins();
		DKGit_GitUpdate();
	}
}

//////////////////////////////////
function DKBuildConsole_SelectOs()
{
	DKDEBUGFUNC();
	console.log("\n");
	console.log("**** SELECT OS TO BUILD ****");
	console.log("1. win32");
	console.log("2. win64");
	console.log("3. mac32");
	console.log("4. mac64");
	console.log("5. linux32");
	console.log("6. linux64");
	console.log("7. ios32");
	console.log("8. ios64");
	console.log("9. iossim32");
	console.log("a. iossim64");
	console.log("b. android32");
	console.log("c. android64");
	console.log("ESC. exit");
	console.log("\n");

	var key = 10;
	while(key == 10){ //unix fix
		key = DK_GetKey();
	}
	//console.log("Key pressed: "+String(key)+"");
	if(key == 27){
		DK_Exit();
	}
	if(key == 49){
		OS = "win32";
	}
	else if(key == 50){
		OS = "win64";
	}
	else if(key == 51){
		OS = "mac32";
	}
	else if(key == 52){
		OS = "mac64";
	}
	else if(key == 53){
		OS = "linux32";
	}
	else if(key == 54){
		OS = "linux64";
	}
	else if(key == 55){
		OS = "ios32";
	}
	else if(key == 56){
		OS = "ios64";
	}
	else if(key == 57){
		OS = "iossim32";
	}
	else if(key == 97){
		OS = "iossim64";
	}
	else if(key == 98){
		OS = "android32";
	}
	else if(key == 99){
		OS = "android64";
	}
	else{
		console.error("INVALID OPTION");
	}
}

/////////////////////////////////////
function DKBuildConsole_SelectApp()
{
	DKDEBUGFUNC();
	console.log("**** SELECT APP TO BUILD ****");
	for(var i=0; i<APP_LIST.length; ++i){
		console.log(DKBuildConsole_TranslateOption(i)+":"+APP_LIST[i]+"");
	}
	console.log("ESC. exit");
	console.log("\n");
	
	var key = 10;
	while(key == 10){ //unix fix
		key = DK_GetKey();
	}
	//console.log("Key pressed: "+String(key)+"");
	if(key == 27){
		DK_Exit();
	}
	
	DKBuildConsole_KeyToApp(key);
	
	if(APP == ""){
		console.error("INVALID OPTION");
	}
}

//////////////////////////////////////
function DKBuildConsole_SelectType()
{
	DKDEBUGFUNC();
	console.log("**** SELECT BUILD TYPE ****");
	console.log("1. Debug");
	console.log("2. Release");
	console.log("3. All");
	console.log("ESC. exit");
	console.log("\n");
	
	var key = 10;
	while(key == 10){ //unix fix
		key = DK_GetKey();
	}
	//console.log("Key pressed: "+String(key)+"");
	if(key == 27){
		DK_Exit();
	}
	if(key == 49){
		TYPE = "Debug";
	}
	else if(key == 50){
		TYPE = "Release";
	}
	else if(key == 51){
		TYPE = "ALL";
	}
	else{
		console.error("INVALID OPTION");
	}
}

/////////////////////////////////
function DKBuildConsole_Process()
{
	DKDEBUGFUNC();
	OS = "";
	APP = "";
	TYPE = "";
	LEVEL = "RebuildAll";
	
	DKBuildConsole_ChooseUpdate();
	
	if(!DKFile_Exists(DKPATH+"/DK/DKPlugins")){
		console.error("ERROR: can't find "+DKPATH+" ");
		DK_GetKey();
		DK_Exit();
	}
	
	while(OS == ""){
		DKBuildConsole_SelectOs();
	}
	console.log("###########################");
	console.log(OS+" ->");
	console.log("###########################");

	DKBuild_GetAppList();
	while(APP == ""){
		DKBuildConsole_SelectApp();
	}
	console.log("###########################");
	console.log(OS+" -> "+APP+" ->");
	console.log("###########################");

	while(TYPE == ""){
		DKBuildConsole_SelectType();
	}
	console.log("###########################");
	console.log(OS+" -> "+APP+" -> "+TYPE+"");
	console.log("###########################");

	console.log("Press any key to Build");
	DK_GetKey();
	
	DKBuild_DoResults();
}

//////////////////////////////////////////////
function DKBuildConsole_TranslateOption(num)
{
	DKDEBUGFUNC();
	if(num == 0){return "1";}
	if(num == 1){return "2";}
	if(num == 2){return "3";}
	if(num == 3){return "4";}
	if(num == 4){return "5";}
	if(num == 5){return "6";}
	if(num == 6){return "7";}
	if(num == 7){return "8";}
	if(num == 8){return "9";}
	if(num == 9){return "a";}
	if(num == 10){return "b";}
	if(num == 11){return "c";}
	if(num == 12){return "d";}
	if(num == 13){return "e";}
	if(num == 14){return "f";}
	if(num == 15){return "g";}
	if(num == 16){return "h";}
	if(num == 17){return "i";}
	if(num == 18){return "j";}
	if(num == 19){return "k";}
	if(num == 20){return "l";}
	if(num == 21){return "m";}
	if(num == 22){return "n";}
	if(num == 23){return "o";}
	if(num == 24){return "p";}
	if(num == 25){return "q";}
	if(num == 26){return "r";}
	if(num == 27){return "s";}
	if(num == 28){return "t";}
	if(num == 29){return "u";}
	if(num == 30){return "v";}
	if(num == 31){return "w";}
	if(num == 32){return "x";}
	if(num == 33){return "y";}
	if(num == 34){return "z";}
}

///////////////////////////////////////
function DKBuildConsole_KeyToApp(key)
{
	DKDEBUGFUNC();
	if(key == 49){ APP = APP_LIST[0]; } //1
	if(key == 50){ APP = APP_LIST[1]; } //2
	if(key == 51){ APP = APP_LIST[2]; } //3 
	if(key == 52){ APP = APP_LIST[3]; } //4
	if(key == 53){ APP = APP_LIST[4]; } //5
	if(key == 54){ APP = APP_LIST[5]; } //6
	if(key == 55){ APP = APP_LIST[6]; } //7
	if(key == 56){ APP = APP_LIST[7]; } //8
	if(key == 57){ APP = APP_LIST[8]; } //9
	if(key == 97){ APP = APP_LIST[9]; } //a
	if(key == 98){ APP = APP_LIST[10]; } //b
	if(key == 99){ APP = APP_LIST[11]; } //c
	if(key == 100){ APP = APP_LIST[12]; } //d
	if(key == 101){ APP = APP_LIST[13]; } //e
	if(key == 102){ APP = APP_LIST[14]; } //f
	if(key == 103){ APP = APP_LIST[15]; } //g
	if(key == 104){ APP = APP_LIST[16]; } //h
	if(key == 105){ APP = APP_LIST[17]; } //i
	if(key == 106){ APP = APP_LIST[18]; } //j
	if(key == 107){ APP = APP_LIST[19]; } //k
	if(key == 108){ APP = APP_LIST[20]; } //l
	if(key == 109){ APP = APP_LIST[21]; } //m
	if(key == 110){ APP = APP_LIST[22]; } //n
	if(key == 111){ APP = APP_LIST[23]; } //o
	if(key == 112){ APP = APP_LIST[24]; } //p
	if(key == 113){ APP = APP_LIST[25]; } //q
	if(key == 114){ APP = APP_LIST[26]; } //r
	if(key == 115){ APP = APP_LIST[27]; } //s
	if(key == 116){ APP = APP_LIST[28]; } //t
	if(key == 117){ APP = APP_LIST[29]; } //u
	if(key == 118){ APP = APP_LIST[30]; } //v
	if(key == 119){ APP = APP_LIST[31]; } //w
	if(key == 120){ APP = APP_LIST[32]; } //x
	if(key == 121){ APP = APP_LIST[33]; } //y
	if(key == 122){ APP = APP_LIST[34]; } //z
}