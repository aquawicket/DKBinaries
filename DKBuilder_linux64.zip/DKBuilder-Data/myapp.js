// browser app script, called from index.html

DKINFO("Hello World!\n");