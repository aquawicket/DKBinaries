<?php
header('Access-Control-Allow-Origin: *');

////////////////////////
function DKINFO($string)
{
	echo "{".$string."}"; //TODO - we may want to replace { } characters with something less used.
}

?>