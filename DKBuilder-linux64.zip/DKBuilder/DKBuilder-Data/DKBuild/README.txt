This Plugin should be a small, and as compatible possible 
The least this can do is create DKIDE for Windows, Mac, and Linux