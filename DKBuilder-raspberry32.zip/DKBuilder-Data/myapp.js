// browser app script, called from index.html

console.log("Hello World!\n");