CPP_DKDuktape_Create("DKBuild/DKBuildConsole.js");
//CPP_DKDuktape_Create("DKUpdate");
